# -*- coding: utf-8 -*-
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.optimizers import SGD,RMSprop,adam
from keras.utils import np_utils
import numpy as np
import matplotlib.pyplot as plt
import os
import theano
from PIL import Image
from numpy import *
from sklearn.utils import shuffle
#import cv2
import sys


Y_pred_all=[0,0,0]
y_pred=None
img_rows, img_cols = 192, 192
img_channels = 1    
if True:
        im1 = np.array(Image.open('D:\Python\Scripts\images\input_test_resized' + '\\'+ 'a002.jpg')) ##���ϸ� �ٲ��ּ���
        m,n = im1.shape[0:2] 
        immatrix = np.array([np.array(Image.open('D:\Python\Scripts\images\input_test_resized' + '\\'+ 'a002.jpg')).flatten()],'f')#���ϸ�           label=np.ones(1,dtype = int)
        data,Label = shuffle(immatrix,label, random_state=2)
        test_data = [data,Label]
        (X, y) = (test_data[0],test_data[1])
        X_test, y_test = (X, y)
        X_test = X_test.reshape(X_test.shape[0], 1, img_rows, img_cols)
        X_test = X_test.astype('float32')
        X_test /= 255
        Y_test = np_utils.to_categorical(y_test, 3)
        model = Sequential()
        model.add(Convolution2D(32,3,3,border_mode='same',input_shape=X_test.shape[1:]))
        model.add(Activation('relu'))
        model.add(MaxPooling2D(pool_size=(2, 2),dim_ordering="th"))
        model.add(Convolution2D(32, 3, 3,border_mode='same'))
        model.add(Activation('relu'))
        model.add(MaxPooling2D(pool_size=(2, 2),dim_ordering="th"))
        model.add(Convolution2D(64, 3, 3,border_mode='same'))
        model.add(Activation('relu'))
        model.add(MaxPooling2D(pool_size=(2, 2),dim_ordering="th"))
        model.add(Flatten())
        model.add(Dense(128))
        model.add(Activation('relu'))
        model.add(Dropout(0.5))
        model.add(Dense(3))
        model.add(Activation('softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adadelta',metrics=["acc"])
        model.load_weights("D:\Python\Scripts\CNN-WEIGHT")        
        Y_pred = model.predict(X_test)
        Y_pred_all = Y_pred_all+ Y_pred


y_pred = np.argmax(Y_pred_all, axis=1)
        
if y_pred == 0:
    print("���!")
    print("������ �湮�� �ּ���")
elif y_pred==1:
    print("����!")
    print("������ �湮�� �ּ���")
elif y_pred==2:
    print("����!")
  


                